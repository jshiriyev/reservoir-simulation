# preprocessing folder

# 1. Reservoir Initialization

# 2. Time Settings
from .numericals import Time
from .numericals import regular

# 3. Well and Boundary Constraints
# from .constraints import Edge
from .constraints import Well
# from .constraints import Locator
# from .constraints import Schedule