import numpy

# from .directory._browser import Browser

def loadsched():

    pass