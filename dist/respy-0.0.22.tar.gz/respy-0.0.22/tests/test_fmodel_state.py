import unittest

import numpy as np

if __name__ == "__main__":
    import dirsetup

import fluids

class TestStateFormulation(unittest.TestCase):

    def test_fluid_incompressible(self):
        pass

    def test_fluid_slightly_compressible(self):
        pass

    def test_fluid_compressible(self):
        pass
                       
if __name__ == "__main__":

    unittest.main()
