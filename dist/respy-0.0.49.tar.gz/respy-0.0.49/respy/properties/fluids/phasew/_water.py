class Water():

    """
    26. properties of reservoir water
    27. water formation volume factor
    28. water viscosity
    29. gas solubility in water
    30. water isothermal compressibility
    """

    def __init__(self):

        pass

    def get_fvf(self):

        pass

    def get_viscosity(self):

        pass

    def get_gas_solubility(self):

        pass

    def get_isothermal_compressibility(self):

        pass