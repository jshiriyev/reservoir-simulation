from ._regular import regular

from ._time import Time