from ._brooks_corey import BrooksCorey
from ._van_genuchten import VanGenuchten